//提交对应表单文件
function submit(i) {
    alert("uploadFile" + i);//uploadFile0
    document.getElementById("uploadFile" + i).submit();
}