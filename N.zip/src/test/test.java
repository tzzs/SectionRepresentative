package test;

public class test {
    public static void main(String args[]) {
        System.out.println(System.currentTimeMillis());
        System.out.println(password.secure.Encrypt("123"));
        System.out.println("f6e0a1e2ac41945a9aa7ff8a8aaa0cebc12a3bcc981a929ad5cf810a090e11ae");

    }
}
